package com.bah.mcc.service;

/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bah.mcc.repository.CustomersRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired	
	public void saveCustomer(Customer customer) {
		repo.save(customer);
	}
	public Iterable<Customer> findAllCustomers(){
		return repo.findAll();
	}
	
	public Optional<Customer> findCustomerById(long id){
		return repo.findById(id);
	}

}*/
