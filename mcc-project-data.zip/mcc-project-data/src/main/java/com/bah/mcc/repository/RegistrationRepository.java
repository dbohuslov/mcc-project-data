package com.bah.mcc.repository;

import org.springframework.data.repository.CrudRepository;

import com.bah.mcc.domain.Registration;

public interface RegistrationRepository extends CrudRepository<Registration, Long>{

}