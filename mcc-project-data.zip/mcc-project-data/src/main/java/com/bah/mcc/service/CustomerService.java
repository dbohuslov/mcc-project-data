/*package com.bah.mcc.service;
import java.util.Optional;

import com.bah.mcc.domain.Customer;

public class CustomerService {
	public void saveCustomer (Customer customer);
	public Iterable<Customer> findAllCustomers();
	public Optional<Customer> findCustomerById(long id);

}*/
